package fabrica;

import jade.core.*;
import jade.core.behaviours.*;
import jade.lang.acl.ACLMessage;

public class Ensamble extends Agent {

    class Receptor extends SimpleBehaviour {

        private boolean fin = false;

        public void action() {
            System.out.println(" Preparandose para recibir");

            //Obtiene el primer mensaje de la cola de mensajes
            ACLMessage mensaje = receive();

            if (mensaje != null) {
                System.out.println(getLocalName() + ": acaba de recibir el siguiente mensaje: ");
                System.out.println(mensaje.toString());
                fin = true;
            }
        }

        public boolean done() {
            return fin;
        }
    }

    protected void setup() {
        addBehaviour(new Receptor());
    }

    public class MiAgente extends Agent {

        private static final String inicio = "inicio";
        private static final String marco = "marco";
        private static final String llantas = "llantas";
        private static final String silla = "silla";
        private static final String fin = "fin";
        private final int UNO = 1;
        private final int DOS = 2;
        private final int TRES = 3;
        private final int Cuatro = 4;
        private final int Cinco = 5;
        private final int Seis = 6;
        private final int Siete = 7;
        private final int Ocho = 8;

        private final int CERO = 0;
        private String entrada = "";

        public void setup() {
            entrada = "231231231";
            MiFSMBehaviour b = new MiFSMBehaviour(this, entrada);
            addBehaviour(b);
        }

        private class MiFSMBehaviour extends FSMBehaviour {

            private int transicion = 0;
            private String entrada = "";

            public MiFSMBehaviour(Agent _agente, String ent) {
                super(_agente);
                entrada = ent;
            }

            public void onStart() {
                registerFirstState(new OneBehaviour(), inicio);
                registerState(new TwoBehaviour(), marco);
                registerState(new ThreeBehaviour(), llantas);
                registerLastState(new ErrorBehaviour(), silla);
                registerLastState(new FinBehaviour(), fin);
                registerTransition(inicio, marco, DOS);
                registerTransition(marco, llantas, TRES);
                registerTransition(marco, silla, Cuatro);
                registerDefaultTransition(llantas, marco, Cinco);
                registerDefaultTransition(llantas, silla, Seis);
                registerDefaultTransition(silla, marco, Ocho);
                registerDefaultTransition(inicio, marco);
                registerDefaultTransition(marco, llantas);
                registerDefaultTransition(llantas, silla);
                registerDefaultTransition(silla, fin);

            }

            protected boolean checkTermination(boolean currentDone, int currentResult) {
                System.out.println("Terminado " + currentName);
                return super.checkTermination(currentDone, currentResult);
            }

            public int getEntrada() {
                int tipoEvento = CERO;
                if (entrada.length() < 1) {
                    return tipoEvento;
                } else {
                    tipoEvento = Integer.parseInt(entrada.substring(0, 1));
                }
                entrada = entrada.substring(1, entrada.length());
                return tipoEvento;
            }

            private class OneBehaviour extends OneShotBehaviour {

                public void action() {
                    System.out.println(" primer estado");
                }

                public int onEnd() {
                    return getEntrada();
                }
            }

            private class TwoBehaviour extends OneShotBehaviour {

                public void action() {
                    System.out.println("Estado del segundo comportamiento");
                }

                public int onEnd() {
                    return getEntrada();
                }
            }

            private class ThreeBehaviour extends OneShotBehaviour {

                public void action() {
                    System.out.println("Estado del tercer comportamiento");
                }

                public int onEnd() {
                    return getEntrada();
                }
            }

            private class FourBehaviour extends OneShotBehaviour {

                public void action() {
                    System.out.println("Estado del cuarto comportamiento");
                }

                public int onEnd() {
                    return getEntrada();
                }
            }

            private class FinBehaviour extends OneShotBehaviour {

                public void action() {
                    System.out.println("Fin  del estado");
                }
            }
        }
    }
}

public Ensamble









() {
    }
    
    class Entrega extends SimpleBehaviour {

    String nameAgent;

    public Entrega(String n) {
        nameAgent = n;
    }

    public void action() {

        doWait(20000);
        ACLMessage acl = new ACLMessage(ACLMessage.REQUEST);
        AID agrec = new AID(nameAgent, AID.ISLOCALNAME);
        acl.addReceiver(agrec);
        acl.setContent("Fabricacion Terminada");
        send(acl);
    }

    public boolean done() {
        return true;
    }

    protected void setup() {

        Object[] listaparametros = getArguments();
        String nameAgenteR = (String) listaparametros[0];

        System.out.println("Fabricacion Terminada");

        Entrega se = new Entrega(nameAgenteR);
        addBehaviour(se);
    }
}
