package miprimeragente;

import jade.core.Agent;
import jade.core.behaviours.*;

/**
 *
 * @author utp
 */
public class AgenteComportamientoSimple extends Agent {

    class TareaSimple extends SimpleBehaviour {

        public void action() {
            for (int i = 0; i < 90; i++) {
                System.out.println("Cilco" + 1);
            }
        }

        public boolean done() {
            System.out.println("Termine");
            return true;
        }

    }

    protected void setup() {

        System.out.println("Primer Agente con Comportamiento Jade");
        TareaSimple cl = new TareaSimple();
        addBehaviour(cl);

    }
}
