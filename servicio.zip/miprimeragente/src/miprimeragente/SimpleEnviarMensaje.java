package miprimeragente;

import jade.core.*;
import jade.core.behaviours.*;
import jade.lang.acl.*;

public class SimpleEnviarMensaje {

    class comportaEnvia extends SimpleBehaviour {

        String nameAgent;

        public comportaEnvia(String n) { nameAgent = n;}
        

        public void action() {

            doWait(20000);
            ACLMessage acl = new ACLMessage(ACLMessage.REQUEST);
            AID agrec = new AID(nameAgent, AID.ISLOCALNAME);
            acl.addReceiver(agrec);
            acl.setContent("mensaje");
            send(acl);
        }

        public boolean done() {
            return true;
        }

    }

    protected void setup() {
        Object[] listaparametros = getArguments();
        String nameAgenteR = (String) listaparametros[0];

        System.out.println("hola mundo soy el primer agente" + getLocalName());

        comportaEnvia ce = new comportaEnvia(nameAgenteR);
        addBehaviour(ce);

    }

}
